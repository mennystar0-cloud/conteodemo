# CKLASS — Demo catálogo

Sube tu archivo a `static/catalogo-master.csv` y abre `index.html`.
